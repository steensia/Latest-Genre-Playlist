import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='steensia',
    application_name='latest-genre-playlist',
    app_uid='mXQhwVky7b30cWNt0K',
    org_uid='83f86a32-fb74-439b-b3e8-ee8b92eed282',
    deployment_uid='0eedb84f-e748-45d6-8ed8-132f0fb5556b',
    service_name='latest-genre-playlist',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.6',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'latest-genre-playlist-dev-latest-genre-playlist', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('latest-genre-playlist.EventHandler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
